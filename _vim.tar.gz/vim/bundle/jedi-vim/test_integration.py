def test_integration(case, monkeypatch, pytestconfig):
    case.run()
